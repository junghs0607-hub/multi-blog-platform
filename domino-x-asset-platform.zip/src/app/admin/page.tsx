"use client";

import React from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { AdminPortalView } from "@/components/admin/AdminPortalView";

export default function AdminPage() {
  return (
    <AppLayout>
      <AdminPortalView />
    </AppLayout>
  );
}
